/*
 * Chat Translate — Sauce for Zwift mod
 * Runs in every Sauce window but only does anything in the Chat window.
 * Replaces each chat message that is not in your chosen language with its translation,
 * marked with a flag + language badge. Click a translated message to toggle the original.
 */
(function() {
    'use strict';
    if (!/\/chat(\.___.+___)?\.html$/.test(location.pathname)) {
        return;
    }

    const STORE_KEY = 's4z-chat-translate-v1';
    const LANGS = [
        ['off', 'Off'], ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'],
        ['it', 'Italian'], ['pt', 'Portuguese'], ['nl', 'Dutch'], ['da', 'Danish'],
        ['sv', 'Swedish'], ['no', 'Norwegian'], ['fi', 'Finnish'], ['pl', 'Polish'],
        ['cs', 'Czech'], ['ru', 'Russian'], ['uk', 'Ukrainian'], ['tr', 'Turkish'],
        ['el', 'Greek'], ['ja', 'Japanese'], ['ko', 'Korean'], ['zh-CN', 'Chinese'],
        ['ar', 'Arabic'], ['he', 'Hebrew'], ['hi', 'Hindi'], ['id', 'Indonesian'],
    ];

    function loadPrefs() {
        let p = {};
        try { p = JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch(e) {/* ignore */}
        if (!p.target) {
            const nav = (navigator.language || 'en').split('-')[0];
            p.target = LANGS.some(([c]) => c === nav) ? nav : 'en';
        }
        return p;
    }
    function savePrefs() {
        try { localStorage.setItem(STORE_KEY, JSON.stringify(prefs)); } catch(e) {/* ignore */}
    }
    const prefs = loadPrefs();

    // ---------- Translation providers ----------
    const cache = new Map();
    let googleBlockedUntil = 0;

    async function viaGoogle(text, target) {
        const url = 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl=auto' +
            `&tl=${encodeURIComponent(target)}&q=${encodeURIComponent(text)}`;
        const r = await fetch(url);
        if (!r.ok) {
            throw new Error(`google ${r.status}`);
        }
        const data = await r.json();
        const translated = (data[0] || []).map(x => x && x[0]).filter(Boolean).join('');
        return {text: translated, source: (data[2] || '').toLowerCase()};
    }

    async function viaMyMemory(text, target) {
        const url = 'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text) +
            `&langpair=autodetect|${encodeURIComponent(target)}`;
        const r = await fetch(url);
        if (!r.ok) {
            throw new Error(`mymemory ${r.status}`);
        }
        const data = await r.json();
        if (data.responseStatus !== 200 && data.responseStatus !== '200') {
            throw new Error(`mymemory ${data.responseDetails || data.responseStatus}`);
        }
        return {
            text: data.responseData.translatedText,
            source: (data.responseData.detectedLanguage || '').toLowerCase(),
        };
    }

    function decodeEntities(s) {
        const t = document.createElement('textarea');
        t.innerHTML = s;
        return t.value;
    }

    async function translate(text, target) {
        const key = target + '\u0000' + text;
        if (cache.has(key)) {
            return cache.get(key);
        }
        const p = (async () => {
            if (Date.now() > googleBlockedUntil) {
                try {
                    return await viaGoogle(text, target);
                } catch(e) {
                    console.warn('Chat Translate: Google failed, falling back', e);
                    googleBlockedUntil = Date.now() + 5 * 60 * 1000;
                }
            }
            const res = await viaMyMemory(text, target);
            res.text = decodeEntities(res.text);
            return res;
        })();
        cache.set(key, p);
        p.catch(() => cache.delete(key));
        if (cache.size > 500) {
            cache.delete(cache.keys().next().value);
        }
        return p;
    }

    // ---------- Chat DOM handling ----------
    const norm = s => s.toLowerCase().replace(/[\s\p{P}]+/gu, '');
    const sameLang = (a, b) => a && b && a.split('-')[0] === b.split('-')[0];

    function originalText(chunk) {
        if (chunk._s4zOrig == null) {
            chunk._s4zOrig = chunk.textContent.trim();
        }
        return chunk._s4zOrig;
    }

    function restoreOriginal(chunk) {
        chunk._s4zTr = null;
        if (chunk.classList.contains('s4z-has-tr')) {
            chunk.classList.remove('s4z-translated', 's4z-has-tr');
            chunk.removeAttribute('title');
            chunk.textContent = chunk._s4zOrig;
        }
    }

    // ---------- Flags ----------
    // Languages spoken mainly in one country get that country's flag.
    // Everything else (English, Spanish, French, German, Portuguese, Arabic, Russian, Chinese...)
    // falls back to the rider's own flag from their Zwift profile.
    const LANG_COUNTRY = {
        ja: 'jp', ko: 'kr', it: 'it', pl: 'pl', cs: 'cz', sk: 'sk', da: 'dk', sv: 'se', no: 'no',
        nb: 'no', nn: 'no', fi: 'fi', el: 'gr', tr: 'tr', uk: 'ua', he: 'il', iw: 'il', hu: 'hu',
        ro: 'ro', th: 'th', vi: 'vn', id: 'id', sl: 'si', hr: 'hr', lt: 'lt', lv: 'lv', et: 'ee',
        is: 'is', bg: 'bg', ka: 'ge', hy: 'am', fa: 'ir',
    };
    const athleteCountry = new Map();  // athleteId -> Promise<alpha2|null>
    let commonMod, flagData;

    // Use Sauce's own page module (same instance the Chat window uses) for RPC + flag data.
    function getCommon() {
        if (!commonMod) {
            commonMod = import(new URL('src/common.mjs', location.href).href);
        }
        return commonMod;
    }

    async function getFlagData() {
        if (!flagData) {
            flagData = getCommon().then(C => C.initNationFlags()).catch(e => {
                flagData = null;
                throw e;
            });
        }
        return flagData;
    }

    function getRiderCountry(athleteId) {
        if (!athleteId) {
            return Promise.resolve(null);
        }
        if (!athleteCountry.has(athleteId)) {
            const p = (async () => {
                const C = await getCommon();
                // allowFetch: pull the Zwift profile if Sauce only has a partial record cached.
                let a = await C.rpc.getAthlete(athleteId, {allowFetch: true});
                if (a && a.countryCode == null) {
                    a = await C.rpc.getAthlete(athleteId, {refresh: true});
                }
                const code = a && a.countryCode;
                if (code == null) {
                    return null;
                }
                const {flags} = await getFlagData();
                const path = flags[code];
                const m = path && path.match(/([a-z]{2})\.png$/);
                return m ? m[1] : null;
            })();
            p.catch(() => athleteCountry.delete(athleteId));
            athleteCountry.set(athleteId, p.catch(() => null));
        }
        return athleteCountry.get(athleteId);
    }

    async function flagFor(lang, chunk) {
        const base = (lang || '').split('-')[0];
        if (LANG_COUNTRY[base]) {
            return LANG_COUNTRY[base];
        }
        const entry = chunk.closest('.entry');
        return await getRiderCountry(entry && Number(entry.dataset.from));
    }

    function makeFlag(alpha2) {
        if (alpha2) {
            const img = document.createElement('img');
            img.className = 's4z-tr-flag';
            img.src = `deps/flags/${alpha2}.png`;
            img.alt = '';
            img.onerror = () => img.replaceWith(document.createTextNode('\u{1F310}'));
            return img;
        }
        const span = document.createElement('span');
        span.className = 's4z-tr-flag';
        span.textContent = '\u{1F310}';
        return span;
    }

    // ---------- Showing / toggling ----------
    function renderChunk(chunk) {
        const st = chunk._s4zTr;
        const showingOriginal = !!chunk._s4zShowOriginal;
        chunk.textContent = '';
        const badge = document.createElement('span');
        badge.className = 's4z-tr-badge' + (showingOriginal ? ' original' : '');
        badge.appendChild(makeFlag(st.flag));
        const code = document.createElement('span');
        code.className = 's4z-tr-code-btn';
        code.textContent = st.lang ? st.lang.split('-')[0].toUpperCase() : '??';
        badge.appendChild(code);
        chunk.appendChild(badge);
        chunk.appendChild(document.createTextNode(' ' + (showingOriginal ? chunk._s4zOrig : st.text)));
        chunk.classList.toggle('s4z-translated', !showingOriginal);
        chunk.classList.add('s4z-has-tr');
        chunk.title = showingOriginal ? 'Click to show translation' :
            'Original: ' + chunk._s4zOrig + '\n(click to show original)';
    }

    function toggleChunk(chunk) {
        if (!chunk._s4zTr) {
            return;
        }
        chunk._s4zShowOriginal = !chunk._s4zShowOriginal;
        renderChunk(chunk);
    }

    // One delegated listener: clicking anywhere on a translated message toggles it.
    // (Double-click still reaches Sauce's "watch this rider" handler; two toggles cancel out.)
    document.addEventListener('click', ev => {
        const chunk = ev.target.closest && ev.target.closest('.entry .message > .chunk.s4z-has-tr');
        if (chunk) {
            toggleChunk(chunk);
        }
    }, true);

    async function showTranslation(chunk, res) {
        const target = chunk._s4zTarget;
        const flag = await flagFor(res.source, chunk);
        if (chunk._s4zTarget !== target || !chunk.isConnected) {
            return;
        }
        chunk._s4zTr = {text: res.text, lang: res.source, flag};
        chunk._s4zShowOriginal = false;
        renderChunk(chunk);
    }

    async function processChunk(chunk) {
        const target = prefs.target;
        const text = originalText(chunk);
        restoreOriginal(chunk);
        chunk._s4zTarget = target;
        if (target === 'off') {
            return;
        }
        // Skip empty or emoji/number-only messages.
        if (!text || !/\p{L}{2,}/u.test(text)) {
            return;
        }
        try {
            const res = await translate(text, target);
            if (chunk._s4zTarget !== target || !chunk.isConnected) {
                return;
            }
            if (sameLang(res.source, target) || !res.text || norm(res.text) === norm(text)) {
                return;
            }
            await showTranslation(chunk, res);
        } catch(e) {
            console.error('Chat Translate error:', e);
        }
    }

    function scan(root) {
        if (root.nodeType !== Node.ELEMENT_NODE) {
            return;
        }
        const chunks = root.matches('.entry .message > .chunk') ?
            [root] : root.querySelectorAll('.entry .message > .chunk');
        for (const c of chunks) {
            if (!c._s4zSeen) {
                c._s4zSeen = true;
                processChunk(c);
            }
        }
    }

    function retranslateAll() {
        for (const c of document.querySelectorAll('.entry .message > .chunk')) {
            processChunk(c);
        }
    }

    // ---------- Title bar language picker ----------
    // Sauce cancels pointerdown on title bar buttons, which stops a native <select> from
    // opening, so this is a small in-page menu instead.
    let menuEl;

    function closeMenu() {
        if (menuEl) {
            menuEl.remove();
            menuEl = null;
        }
    }

    function syncPicker() {
        const btn = document.querySelector('#titlebar .s4z-tr-picker');
        if (!btn) {
            return;
        }
        btn.classList.toggle('off', prefs.target === 'off');
        btn.querySelector('.s4z-tr-code').textContent =
            prefs.target === 'off' ? '' : prefs.target.split('-')[0].toUpperCase();
    }

    function setTarget(code) {
        if (code === prefs.target) {
            return;
        }
        prefs.target = code;
        savePrefs();
        syncPicker();
        retranslateAll();
    }

    function openMenu(btn) {
        closeMenu();
        menuEl = document.createElement('div');
        menuEl.className = 's4z-tr-menu';
        const head = document.createElement('div');
        head.className = 's4z-tr-menu-head';
        head.textContent = 'Translate chat to';
        menuEl.appendChild(head);
        for (const [code, name] of LANGS) {
            const item = document.createElement('div');
            item.className = 's4z-tr-menu-item' + (code === prefs.target ? ' selected' : '');
            item.dataset.code = code;
            item.textContent = name;
            menuEl.appendChild(item);
        }
        menuEl.addEventListener('click', ev => {
            ev.stopPropagation();
            const item = ev.target.closest('.s4z-tr-menu-item');
            if (item) {
                setTarget(item.dataset.code);
                closeMenu();
            }
        });
        document.body.appendChild(menuEl);
        const r = btn.getBoundingClientRect();
        const w = menuEl.offsetWidth;
        menuEl.style.top = Math.round(r.bottom + 2) + 'px';
        menuEl.style.left = Math.max(4, Math.min(r.right - w, window.innerWidth - w - 4)) + 'px';
        menuEl.style.maxHeight = Math.max(80, window.innerHeight - r.bottom - 10) + 'px';
        try { menuEl.querySelector('.selected').scrollIntoView({block: 'nearest'}); } catch(e) {/* ignore */}
    }

    function addPicker() {
        const buttons = document.querySelector('#titlebar .buttons');
        if (!buttons || buttons.querySelector('.s4z-tr-picker')) {
            return;
        }
        const btn = document.createElement('div');
        btn.className = 'button s4z-tr-picker';
        btn.title = 'Chat Translate: choose language';
        btn.innerHTML = '<ms>translate</ms><span class="s4z-tr-code"></span>';
        btn.addEventListener('click', ev => {
            ev.stopPropagation();
            if (menuEl) {
                closeMenu();
            } else {
                openMenu(btn);
            }
        });
        buttons.insertBefore(btn, buttons.firstChild);
        syncPicker();
        document.addEventListener('click', ev => {
            if (menuEl && !ev.target.closest('.s4z-tr-menu, .s4z-tr-picker')) {
                closeMenu();
            }
        });
        document.addEventListener('keydown', ev => ev.key === 'Escape' && closeMenu());
        window.addEventListener('blur', closeMenu);
    }

    // Keep other Chat windows (if several are open) in sync.
    window.addEventListener('storage', ev => {
        if (ev.key === STORE_KEY) {
            const next = loadPrefs().target;
            if (next !== prefs.target) {
                prefs.target = next;
                syncPicker();
                retranslateAll();
            }
        }
    });

    function start() {
        const content = document.querySelector('#content');
        if (!content) {
            return setTimeout(start, 200);
        }
        try { addPicker(); } catch(e) {/* ignore */}
        scan(content);
        new MutationObserver(muts => {
            for (const m of muts) {
                for (const n of m.addedNodes) {
                    if (n.nodeType === Node.ELEMENT_NODE && !n.classList.contains('s4z-tr-badge')) {
                        scan(n);
                    }
                }
            }
        }).observe(content, {childList: true, subtree: true});
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
})();
